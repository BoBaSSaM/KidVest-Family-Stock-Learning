---
name: Playful Tactile Adventure
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#434655'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006e2f'
  on-secondary: '#ffffff'
  secondary-container: '#6bff8f'
  on-secondary-container: '#007432'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cea700'
  on-tertiary-container: '#4e3d00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#6bff8f'
  secondary-fixed-dim: '#4ae176'
  on-secondary-fixed: '#002109'
  on-secondary-fixed-variant: '#005321'
  tertiary-fixed: '#ffe083'
  tertiary-fixed-dim: '#eec200'
  on-tertiary-fixed: '#231b00'
  on-tertiary-fixed-variant: '#574500'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  display:
    fontFamily: Nunito Sans
    fontSize: 40px
    fontWeight: '900'
    lineHeight: 52px
  display-mobile:
    fontFamily: Nunito Sans
    fontSize: 32px
    fontWeight: '900'
    lineHeight: 40px
  headline-lg:
    fontFamily: Nunito Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Nunito Sans
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 32px
  headline-md:
    fontFamily: Nunito Sans
    fontSize: 22px
    fontWeight: '800'
    lineHeight: 28px
  headline-sm:
    fontFamily: Nunito Sans
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  body-lg:
    fontFamily: Nunito Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-md:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-sm:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-lg:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '800'
    lineHeight: 20px
  label-md:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 18px
  label-sm:
    fontFamily: Nunito Sans
    fontSize: 12px
    fontWeight: '800'
    lineHeight: 16px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.25rem
---

## Brand & Style

The design system is engineered for a dual-language (RTL primary Arabic, LTR secondary English) gamified fintech experience for children ages 7–12. The brand personality balances financial literacy and empowerment with video game energy: energetic, forgiving, tactile, and clear. 

The aesthetic is **Tactile Toy-Box Pop**:
- Chunky, bubbly visual affordances that simulate physical arcade buttons, cards, and reward tokens.
- Warm, cheerful atmosphere built on creamy sand foundations rather than clinical banking starkness.
- High-clarity interactive components designed for emerging motor skills and rapid visual scanning.
- Visual storytelling through cheerful mascot dialog frames, bouncy progress milestones, and immediate celebratory micro-feedback.
- Seamless bidirectional symmetry: all spatial metaphors, layouts, gestures, and UI alignments default to Right-to-Left (RTL) with native bidirectional mirroring for Latin scripts.

## Colors

The palette uses saturated game-tier primaries set against an ultra-soft, eye-comfort background to avoid visual fatigue during interactive lessons.

- **Canvas & Backgrounds**:
  - `canvas-default`: `#FFF9F0` (Warm Sand Canvas)
  - `surface-card`: `#FFFFFF` (Stark Bright Card)
  - `surface-elevated`: `#FEF3C7` (Warm Amber Glow Surface)
- **Brand & Action Roles**:
  - `primary` (Quest Blue): `#2563EB` — Primary interactions, key pathways, major actions.
  - `primary-shadow`: `#1D4ED8` — Tactile extrusion bevel for primary elements.
  - `secondary` (Leaf Green): `#22C55E` — Growth, earnings, completed savings goals, approvals.
  - `secondary-shadow`: `#15803D` — Tactile extrusion bevel for success elements.
  - `tertiary` (Coin Yellow): `#FACC15` — Gold coins, star points, quest tokens, streaks.
  - `tertiary-shadow`: `#CA8A04` — Tactile extrusion bevel for coin/gold elements.
  - `magic` (Level Purple): `#8B5CF6` — Mastery levels, magic chests, bonus multipliers.
  - `magic-shadow`: `#6D28D9` — Tactile extrusion bevel for magic elements.
  - `danger` (Coral Warning): `#FB7185` — Critical alerts, spent balance, debit confirmations.
  - `danger-shadow`: `#E11D48` — Tactile extrusion bevel for destructive actions.
- **Typography & Structure**:
  - `text-primary`: `#1E293B` (Deep Navy) — High-contrast readability meeting WCAG AAA.
  - `text-muted`: `#64748B` (Slate Muted) — Instructional labels, supporting metrics.
  - `border-neutral`: `#E2E8F0` — Clean framing for cards and containers.
  - `border-highlight`: `#FDE68A` — Gamified celebratory outlines and reward card borders.

## Typography

Typography is calibrated to offer high legibility, generous counter-spaces, and open terminals to assist early readers. 

- **Font Stack Hierarchy**:
  - **Arabic Primary**: Use rounded geometric Arabic typefaces with balanced vertical proportions (`Baloo Bhaijaan 2`, `Cairo`, or `Tajawal`).
  - **Latin Primary**: `Nunito Sans` with fallback to `Comfortaa` or `Quicksand`.
- **RTL Considerations**:
  - Arabic scripts naturally demand 10–15% more vertical line spacing (`line-height`) than Latin scripts to prevent overlaps between Tashkeel (diacritics) and descenders.
  - Numbers default to Eastern Arabic numerals (`٠ ١ ٢ ٣ ٤ ٥ ٦ ٧ ٨ ٩`) in full Arabic mode, or standard numerals with localized currency badges (`SAR`, `AED`, `EGP`, `Coins`).
  - Never use condensed or light weights; all interactive and informative text maintains a minimum weight of `600` (SemiBold) to ensure high legibility on physical screens under bright conditions.

## Layout & Spacing

The layout is built around a flexible 4-column system for mobile devices (`< 600px`), 8-column for tablets (`600px - 1023px`), and 12-column max-contained width (`1200px`) on desktop/tablets in landscape.

- **RTL Directional Rhythm**:
  - Global default is `dir="rtl"`.
  - Margins, back buttons, progress meters, and flow chevrons automatically reverse when switching between Arabic and English.
- **Ergonomics & Touch Targets**:
  - All interactive items (cards, buttons, icons, avatars) conform to a strict minimum hit area of `48px × 48px` (ideally `56px` for primary quest buttons).
  - Bottom navigation and core action trays are placed within the primary thumb zone of mobile devices.
- **Vertical Rhythm**:
  - Layout relies on consistent 8px/16px stacking increments (`space-sm`, `space-md`, `space-lg`) to maintain consistent gaps between gamified modules.

## Elevation & Depth

Visual hierarchy uses physical, 3D extruded "chunky toy" drop-bevels rather than diffuse, photorealistic shadows. This visual feedback communicates physical push-states to children.

- **Level 1 (Flat Cards & Resting Containers)**:
  - Surface: `#FFFFFF`
  - Border: 2px solid `#E2E8F0`
  - Shadow: `0 4px 0 0 #CBD5E1`
- **Level 2 (Active Interactive Buttons & Badges - Resting)**:
  - Blue Primary: `box-shadow: 0 4px 0 0 #1D4ED8`
  - Green Success: `box-shadow: 0 4px 0 0 #15803D`
  - Yellow Coins: `box-shadow: 0 4px 0 0 #CA8A04`
  - Purple Magic: `box-shadow: 0 4px 0 0 #6D28D9`
  - Coral Danger: `box-shadow: 0 4px 0 0 #E11D48`
- **Level 2 (Active Interactive Buttons - Pressed State)**:
  - Transform: `translateY(4px)`
  - Shadow collapses to: `0 0 0 0 transparent`
  - Audio/Haptic micro-cue triggers instantly.
- **Level 3 (Floating Reward Overlays & Mascot Dialogs)**:
  - Surface: `#FFFFFF`
  - Border: 3px solid `#FACC15` or `#2563EB`
  - Shadow: `0 8px 0 0 #1E293B`, accompanied by a 20% tinted backdrop mask (`rgba(30, 41, 59, 0.4)`).

## Shapes

The shape system uses soft, organic roundness (Pill-shaped / Level 3) to reinforce playfulness, safety, and touchability.

- **Component Shapes**:
  - **Buttons & Chips**: Fully pill-shaped (`border-radius: 9999px`).
  - **Cards & Quest Boards**: 24px (`1.5rem`) to 32px (`2rem`) radius for friendly, pebble-like envelopes.
  - **Inputs & Progress Tracks**: 16px to fully circular caps.
  - **Speech Bubbles**: Rounded rectangular cards (20px radius) featuring a directional triangular speech tail anchored toward the character avatar (tail points right in RTL mode, left in LTR mode).
  - **Coins & Badges**: Perfect circular badges with double concentric border trims.

## Components

### 1. Buttons
- **Primary Arcade Button**: Height of 52px minimum, pill shape (`rounded-full`), weight 800 text. Background `#2563EB`, text `#FFFFFF`, border none, bottom shadow `0 5px 0 #1D4ED8`. Active state: `translateY(4px)` with shadow reduced to `0 1px 0 #1D4ED8`.
- **Secondary Coin / Reward Button**: Background `#FACC15`, text `#1E293B`, bottom shadow `0 5px 0 #CA8A04`. Active translation matches primary button.
- **Ghost / Utility Button**: Background `#FFFFFF`, border `2px solid #E2E8F0`, shadow `0 4px 0 #E2E8F0`, text `#1E293B`.

### 2. Coins & Reward Chips
- **Coin Indicator Chip**: Pill-shaped container (`#FEF3C7`), border `2px solid #FDE68A`, padding `4px 14px 4px 8px` (mirrored in RTL). Contains a 24px golden coin icon on the leading edge, followed by tabular bold text (`#1E293B`).
- **Level / Streak Chip**: Purple tinted background (`#F3E8FF`), border `2px solid #D8B4FE`, displaying current level badge and flame streak counter.

### 3. Cards & Mission Tiles
- White canvas surface (`#FFFFFF`) with 2px solid `#E2E8F0` border and `0 6px 0 #E2E8F0` resting shadow. 
- Internal padding: `space-lg` (24px).
- Incorporates a leading status badge, an illustrative iconography zone, title, progress bar, and an RTL-aware trailing completion indicator or action button.

### 4. Mascot Callout Bubble
- Playful prompt dialogue container. Surface: `#FFFFFF`, border: `2.5px solid #2563EB`, shadow: `0 4px 0 #DBEAFE`.
- An integrated pointer/tail (width 16px, height 12px) positioned toward the character mascot. In `dir="rtl"` the mascot and pointer sit on the right margin; in `dir="ltr"` they anchor to the left.

### 5. Form Fields & Number Inputs
- Large, comfortable inputs with min-height of 56px.
- Background: `#FFFFFF`, border: `2.5px solid #CBD5E1`, border-radius: 16px.
- Focused state: Border changes to `#2563EB` with an ambient glow (`0 0 0 4px #DBEAFE`).
- Large numeric size (`headline-md`) centered or leading-aligned with integrated quick-tap stepper buttons (`+` and `-`) sized at 44px.

### 6. Interactive Checkboxes & Radio Selection Cards
- **Gamified Quiz Card**: Replaces traditional tiny checkboxes with large, selectable tactile cards. Unselected: `#FFFFFF` with `#E2E8F0` border. Selected: `#EFF6FF` background, `2.5px solid #2563EB`, with a big checkmark pill.
- **Toggles**: Chunky switch track (60px × 34px) with a physical sliding circular thumb (26px) that pops when toggled.

### 7. Gamified Progress Bar
- Height of 20px, fully pill-shaped track in `#E2E8F0` with inset shadow.
- Fill: `#22C55E` or `#FACC15` featuring a subtle candy-stripe pattern or glossy overlay highlight running across the top edge.
- Trailing reward chest icon pinned to the goal terminal.